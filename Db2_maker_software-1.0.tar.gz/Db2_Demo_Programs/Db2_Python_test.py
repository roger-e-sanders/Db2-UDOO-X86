#! /usr/bin/python3
#-------------------------------------------------------------------------------------------------#
#  NAME:     Db2_Python_test.py                                                                   #
#                                                                                                 #
#  PURPOSE:  This program is designed to query the DEPARTMENT table in the Db2 SAMPLE database    #
#            and display the results in a format that is similar to that returned when the same   #
#            table is queried using the Db2 Command Line Processor (CLP).                         #
#                                                                                                 #
#  USAGE:    Log in as the Db2 instance owner (typically, db2inst1) and issue the following       #
#            command from a Linux terminal window:                                                #
#                                                                                                 #
#                 ./Db2_Python_test.sh                                                            #
#                                                                                                 #
#-------------------------------------------------------------------------------------------------#
#                      DISCLAIMER OF WARRANTIES AND LIMITATION OF LIABILITY                       #
#                                                                                                 #
#  (C) COPYRIGHT International Business Machines Corp. 2017, 2018 All Rights Reserved             #
#  Licensed Materials - Property of IBM                                                           #
#                                                                                                 #
#  US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP   #
#  Schedule Contract with IBM Corp.                                                               #
#                                                                                                 #
#  The following source code ("Sample") is owned by International Business Machines Corporation   #
#  or one of its subsidiaries ("IBM") and is copyrighted and licensed, not sold. You may use,     #
#  copy, modify, and distribute the Sample in any form without payment to IBM, for the purpose of #
#  assisting you in the creation of a simple database that is designed to store humidity and      #
#  temperature data.                                                                              #
#                                                                                                 #
#  The Sample code is provided to you on an "AS IS" basis, without warranty of any kind. IBM      #
#  HEREBY EXPRESSLY DISCLAIMS ALL WARRANTIES, EITHER EXPRESS OR IMPLIED, INCLUDING, BUT NOT       #
#  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.    #
#  Some jurisdictions do not allow for the exclusion or limitation of implied warranties, so the  #
#  above limitations or exclusions may not apply to you. IBM shall not be liable for any damages  #
#  you suffer as a result of using, copying, modifying or distributing the Sample, even if IBM    #
#  has been advised of the possibility of such damages.                                           #
#-------------------------------------------------------------------------------------------------#
#  HISTORY: 01JAN2018 - Initial Coding                                   roger.sanders@us.ibm.com #
#-------------------------------------------------------------------------------------------------#
# Load The Python Module That Is Required To Work With Db2 Databases
import ibm_db

# Connect To The SAMPLE Database (As The Db2 Instance Owner)
conn = ibm_db.connect('sample', 'db2inst1', 'ibmdb2')

# If A Database Connection Was Established, ...
if conn:

    # Retrieve Data From The DB2INST1.DEPARTMENT Table
    sql_stmt = "SELECT * FROM DB2INST1.DEPARTMENT"
    record = ibm_db.exec_immediate(conn, sql_stmt)

    # Display A Report Header
    print()
    print("DEPTNO DEPTNAME                             MGRNO  ADMRDEPT LOCATION")
    print("------ ------------------------------------ ------ -------- --------")
    
    # As Long As There Are Records, Retrieve Them
    num_records = 0
    while (ibm_db.fetch_row(record)):

        # Extract The Data Value For Each Column From The Record Retrieved
        deptno = ibm_db.result(record, 0)
        deptname = ibm_db.result(record, 1)
        mgrno = ibm_db.result(record, 2)
        admrdept = ibm_db.result(record, 3)
        location = ibm_db.result(record, 4)

        # Format And Display The Data Retrieved
        print("{0:6} {1:34}   " .format(deptno, deptname), end="")
        if mgrno:
            print("{0:6} " .format(mgrno), end="")
        else:
            print("-      ", end="")
        if admrdept:
            print("{0:8} " .format(admrdept), end="")
        else:
            print("-       ", end="")
        if location:
            print("{0} " .format(location))
        else:
            print("-")

        # Increment The Record Counter
        num_records += 1

    # Display The Number Of Records Found
    print()
    print("  {} record(s) selected." .format(num_records))
    print()

# Close The Database Connection That Was Opened Earlier
ibm_db.close(conn)

# Exit And Return Control To The Operating System
exit()
