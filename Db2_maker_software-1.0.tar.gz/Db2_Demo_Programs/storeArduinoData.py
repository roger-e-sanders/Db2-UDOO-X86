#! /usr/bin/python3
#-------------------------------------------------------------------------------------------------#
#  NAME:     storeArduinoData.py                                                                  #
#                                                                                                 #
#  PURPOSE:  This program is designed to retrieve humidity and temperature data fron an Arduino   #
#            Data Output Port and INSERT it into a Db2 Developer-C database table.                # 
#                                                                                                 #
#  USAGE:    Log in as a Db2 database instance user (for example, db2inst1) and issue the         #
#            following command from a Linux terminal window:                                      #
#                                                                                                 #
#            ./storeArduinoData                                                                   #
#                                                                                                 #
#-------------------------------------------------------------------------------------------------#
#                      DISCLAIMER OF WARRANTIES AND LIMITATION OF LIABILITY                       #
#                                                                                                 #
#  (C) COPYRIGHT International Business Machines Corp. 2017 All Rights Reserved                   #
#  Licensed Materials - Property of IBM                                                           #
#                                                                                                 #
#  US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP   #
#  Schedule Contract with IBM Corp.                                                               #
#                                                                                                 #
#  The following source code ("Sample") is owned by International Business Machines Corporation   #
#  or one of its subsidiaries ("IBM") and is copyrighted and licensed, not sold. You may use,     #
#  copy, modify, and distribute the Sample in any form without payment to IBM, for the purpose of #
#  assisting you in the creation of a simple database that is designed to store humidity and      #
#  temperature data.                                                                              #
#                                                                                                 #
#  The Sample code is provided to you on an "AS IS" basis, without warranty of any kind. IBM      #
#  HEREBY EXPRESSLY DISCLAIMS ALL WARRANTIES, EITHER EXPRESS OR IMPLIED, INCLUDING, BUT NOT       #
#  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.    #
#  Some jurisdictions do not allow for the exclusion or limitation of implied warranties, so the  #
#  above limitations or exclusions may not apply to you. IBM shall not be liable for any damages  #
#  you suffer as a result of using, copying, modifying or distributing the Sample, even if IBM    #
#  has been advised of the possibility of such damages.                                           #
#-------------------------------------------------------------------------------------------------#
#  HISTORY: 26SEP2017 - Initial Coding                                   roger.sanders@us.ibm.com #
#-------------------------------------------------------------------------------------------------#

# Load The Appropriate Python Modules
import sys
import serial
import ibm_db # (Required To Work With Db2 Databases)

# Connect To The Appropriate Db2 Database (MY_DATA)
db_conn = ibm_db.connect('my_data', 'db2inst1', 'ibmdb2')

# Attempt To Open The Arduino Data Output Port (If The Port Can't Be Opened Display
# An Error Message And Exit)
arduinoPort = '/dev/ttyACM0'
print "Connecting to port '%s'" %arduinoPort + "...",
try:
    arduino = serial.Serial(arduinoPort, 9600, timeout=5)    # Open The Port
    print "Done!"
except:
    print "\nUnable to connect to '%s'" %arduinoPort
    sys.exit()

# Construct The First Part Of The SQL Statement That Will Be Used To Add The Data 
# Collected To The Database
stmt1 = "INSERT INTO udoo.dht22_data (pct_humidity, temp_c, heat_index_c, temp_f, heat_index_f) "

# Set Up A Loop To Continuously Read Data Coming From The Arduino Data Output Port
errorFound = 0
while errorFound < 1:
    try:
        # Read A Line Of Data
        line = arduino.readline()

        # If There Is No Data, Exit The Loop
        numBytes = len(line)
        if numBytes == 0:
            break

        # If There Is Data, Break The Line Read Into Five Separate Values
        else:
            pieces = line.split("\t")

            # Construct The INSERT Statement That Will Be Used To Insert The Data Retrieved 
            # Into The Appropriate Db2 Database Table
            pieces[4] = pieces[4].rstrip('\n')
            stmt2 = "VALUES (%s, %s, %s, %s, %s)" %(pieces[0], pieces[1], pieces[2], pieces[3], pieces[4])
            sql_stmt = stmt1 + stmt2

            # Display The Data Retrieved
            print "Humidity: %s %%" %pieces[0] + "   ",
            print "Temp (C): %s" %pieces[1] + "   ",
            print "Heat Index (C): %s" %pieces[2] + "   ",
            print "Temp (F): %s" %pieces[3] + "   ",
            print "Heat Index (F) = %s" %pieces[4]

            # Insert The Data Retrieved Into The Table (If A Row Was Successfully Inserted, 
            # Display A Message)
            result = ibm_db.exec_immediate(db_conn, sql_stmt)
            if result >= 1:
                print "%s row(s) inserted into database MY_DATA" %ibm_db.num_rows(result)
                print ""
            continue

    # If Data Could Not Be Read From The Arduino Data Output Port, Exit The Loop
    except:
        print "\nUnable to retrieve data from '%s'" %arduinoPort + "\n"
        break

# Close The Database Connection Opened Earlier
ibm_db.close(db_conn)

# Attempt To Close The Arduino Data Output Port
print "Disconnecting from port '%s'" %arduinoPort + "...",
try:
    arduino.close()
    print "Done!"
except:
    print "\nUnable to disconnect from '%s'" %arduinoPort
