#!/bin/bash
#-------------------------------------------------------------------------------------------------#
#  NAME:     maker_env_setup.sh                                                                   #
#                                                                                                 #
#  PURPOSE:  This program is designed to install the Ubuntu Linux libraries, Python packages,     #
#            and Arduino sketches that are needed to set up the UDOO X86-based Db2 maker project. #
#                                                                                                 #
#  USAGE:    Log in as the root user and issue the following command from a Linux terminal        #
#            window:                                                                              #
#                                                                                                 #
#                 ./maker_env_setup.sh [UserName]                                                 #
#                                                                                                 #
#                 where UserName is the name of a valid user.                                     #
#                                                                                                 #
#-------------------------------------------------------------------------------------------------#
#                      DISCLAIMER OF WARRANTIES AND LIMITATION OF LIABILITY                       #
#                                                                                                 #
#  (C) COPYRIGHT International Business Machines Corp. 2017, 2018 All Rights Reserved             #
#  Licensed Materials - Property of IBM                                                           #
#                                                                                                 #
#  US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP   #
#  Schedule Contract with IBM Corp.                                                               #
#                                                                                                 #
#  The following source code ("Sample") is owned by International Business Machines Corporation   #
#  or one of its subsidiaries ("IBM") and is copyrighted and licensed, not sold. You may use,     #
#  copy, modify, and distribute the Sample in any form without payment to IBM, for the purpose of #
#  assisting you in the creation of a simple database that is designed to store humidity and      #
#  temperature data.                                                                              #
#                                                                                                 #
#  The Sample code is provided to you on an "AS IS" basis, without warranty of any kind. IBM      #
#  HEREBY EXPRESSLY DISCLAIMS ALL WARRANTIES, EITHER EXPRESS OR IMPLIED, INCLUDING, BUT NOT       #
#  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.    #
#  Some jurisdictions do not allow for the exclusion or limitation of implied warranties, so the  #
#  above limitations or exclusions may not apply to you. IBM shall not be liable for any damages  #
#  you suffer as a result of using, copying, modifying or distributing the Sample, even if IBM    #
#  has been advised of the possibility of such damages.                                           #
#-------------------------------------------------------------------------------------------------#
#  HISTORY: 01JAN2018 - Initial Coding                                   roger.sanders@us.ibm.com #
#-------------------------------------------------------------------------------------------------#


#-------------------------------------------------------------------------------------------------#
#  NAME:        init_log_file()                                                                   #
#                                                                                                 #
#  PURPOSE:     This function writes the appropriate header information to the Db2 maker          #
#               environment setup up script log file (maker_env_setup.log).                       #
#                                                                                                 #
#  PARAMETERS:  $1 - Log file name                                                                #
#                                                                                                 #
#  RETURNS:     None                                                                              #
#-------------------------------------------------------------------------------------------------#
function init_log_file
{
    # Create A New Log File And Write The Appropriate Header Information To It
    echo "#--------------------------------------------------------------------#"  > ${1} 2>&1
    echo "#  NAME:      maker_env_setup.log                                    #" >> ${1} 2>&1
    echo "#  CREATED:   ${TimeStamp}                                    #" >> ${1} 2>&1
    echo "#                                                                    #" >> ${1} 2>&1
    echo "#  CONTENTS:  Log data produced by maker_dev_setup.sh                #" >> ${1} 2>&1
    echo "#--------------------------------------------------------------------#" >> ${1} 2>&1
    echo "" >> ${1} 2>&1

    # Change Permissions On The Log File So Anyone Can Access It
    chmod 777 ${1}
}


#-------------------------------------------------------------------------------------------------#
#  NAME:        check_input_parameter()                                                           #
#                                                                                                 #
#  PURPOSE:     This function examines the value that was passed to this script when it was       #
#               invoked to determine if it is a valid user name.                                  #
#                                                                                                 #
#  PARAMETERS:  $1 - Parameter passed (user name)                                                 #
#               $2 - Log file name                                                                #
#                                                                                                 #
#  RETURNS:     TRUE  (1) - A valid user name was provided                                        #
#               FALSE (0) - A valid user name was not provided                                    #
#-------------------------------------------------------------------------------------------------#
function check_input_parameter
{
    # Define All Local Variables Used
    local UserName=${UserName:=''}               # User Name
    local UserExists=${UserExists:=0}            # User Exists Flag
    local ReturnCode=${ReturnCode:=0}            # Function Return Code

    # Initialize The Appropriate Memory Variables
    UserName=${1}
    UserExists=1
    ReturnCode=${FALSE}

    # Display A Status Message Indicating Checking Is Being Done To Confirm That This Script Was
    # Called Appropriately
    date >> ${2} 2>&1
    echo "Confirming that this script was called appropriately." | tee -a ${2}
    echo "" | tee -a ${2}

    # See If The Parameter Value Passed To This Shell Script Is The Name Of A Valid User
    UserExists=$(id -u ${UserName} > /dev/null 2>&1; echo $?)
    if [ ${UserExists} == 0 ]
    then
        ReturnCode=${TRUE}
    fi

    # If Parameter Value Passed Is Not The Name Of A Valid User, Display An Error Message And 
    # Prepare To Return To The Calling Function
    if [ ${ReturnCode} == ${FALSE} ]
    then
        date >> ${2} 2>&1
        echo -n "ERROR: This script must be called with a valid user name " | tee -a ${2}
        echo "specified." | tee -a ${2}
        echo "       User name \"${UserName}\" is not a valid user name." | tee -a ${2}
        echo "" | tee -a ${2}
    fi

    # Return The Appropriate Value To The Calling Function
    return ${ReturnCode}
}


#-------------------------------------------------------------------------------------------------#
#  NAME:        install_packages_and_libraries()                                                  #
#                                                                                                 #
#  PURPOSE:     This function installs the Ubuntu Linux libraries and Python packages needed.     #
#                                                                                                 #
#  PARAMETERS:  $1 - Log file name                                                                #
#                                                                                                 #
#  RETURNS:     TRUE  (1) - Packages and libraries needed were installed                          #
#               FALSE (0) - One or more packages and libraries needed were not installed          #
#-------------------------------------------------------------------------------------------------#
function install_packages_and_libraries
{
    # Define All Local Variables Used
    local ReturnCode=${ReturnCode:=0}            # Function Return Code

    # Initialize The Appropriate Memory Variables
    ReturnCode=${FALSE}

    # Upgrade The Entire Operating System    
    date >> ${1} 2>&1
    echo "Installing newer versions of all packages currently installed." | tee -a ${1}
    echo "(this may take a few minutes)."
    echo "" >> ${1}
    apt-get -y upgrade >> ${1} 2>&1 
    echo "" >> ${1}
    echo "" | tee -a ${1}

    # Remove Packages That Are No Longer Needed
    echo "Removing packages that are no longer required." | tee -a ${1}
    echo "" >> ${1}
    apt-get -y autoremove >> ${1} 2>&1 
    echo "" >> ${1}
    echo "" | tee -a ${1}

    # Install The LIBAIO1 Linux Library
    echo "Installing the libaio1 package" | tee -a ${1}
    echo "" >> ${1}
    apt-get -y install libaio1 >> ${1} 2>&1 
    echo "" >> ${1}
    echo "" | tee -a ${1}

    # Install The BINUTILS Linux Library
    echo "Installing the binutils package" | tee -a ${1}
    echo "" >> ${1}
    apt-get -y install binutils >> ${1} 2>&1  
    echo "" >> ${1}
    echo "" | tee -a ${1}

    # Install The ZLIB1G Linux Library
    echo "Installing the zlib1g-dev package" | tee -a ${1}
    echo "" >> ${1}
    apt-get -y install zlib1g-dev >> ${1} 2>&1 
    echo "" >> ${1}
    echo "" | tee -a ${1}

    # Install The LIBPAM0G:I386 Linux Library
    echo "Installing the libpam0g:i386 package" | tee -a ${1}
    echo "" >> ${1}
    apt-get -y install libpam0g:i386 >> ${1} 2>&1 
    echo "" >> ${1}
    echo "" | tee -a ${1}

    # Install The LIBSTDC++:I386 Linux Library
    echo "Installing the libstdc++6:i386 package" | tee -a ${1}
    echo "" >> ${1}
    apt-get -y install libstdc++6:i386 >> ${1} 2>&1 
    echo "" >> ${1}
    echo "" | tee -a ${1}

    # Install The OPENSSH-SERVER Linux Library
    echo "Installing the openssh-server package" | tee -a ${1}
    echo "" >> ${1}
    apt-get -y install openssh-server >> ${1} 2>&1 
    echo "" >> ${1}
    echo "" | tee -a ${1}

    # Install The ARDUINO-MK Linux Library
    echo "Installing the arduino-mk package" | tee -a ${1}
    echo "" >> ${1}
    apt-get -y install arduino-mk >> ${1} 2>&1 
    echo "" >> ${1}
    echo "" | tee -a ${1}

    # Install The SETUPTOOLS Python 3.5 Package
    echo "Installing the python3-setuptools package" | tee -a ${1}
    echo "" >> ${1}
    apt-get -y install python3-setuptools >> ${1} 2>&1 
    echo "" >> ${1}
    echo "" | tee -a ${1}

    # Install The PIP Python 3.5 Package
    echo "Installing the python3-pip package" | tee -a ${1}
    echo "" >> ${1}
    apt-get -y install python3-pip >> ${1} 2>&1 
    echo "" >> ${1}
    echo "" | tee -a ${1}

    # Upgrade The PIP Python 3.5 Package
    echo "Upgrading the Python pip application" | tee -a ${1}
    echo "" >> ${1}
    pip3 install -U pip >> ${1} 2>&1 
    echo "" >> ${1}
    echo "" | tee -a ${1}

    # Install The DEV Python 3.5 Package
    echo "Installing the python3-dev package" | tee -a ${1}
    echo "" >> ${1}
    apt-get -y install python3-dev >> ${1} 2>&1  
    echo "" >> ${1}
    echo "" | tee -a ${1}

    # Install The LXML Python 3.5 Package
    echo "Installing the python3-lxml package" | tee -a ${1}
    echo "" >> ${1}
    apt-get -y install python3-lxml >> ${1} 2>&1 
    echo "" >> ${1}
    echo "" | tee -a ${1}

    # Install The GCC Compiler
    echo "Installing the gcc compiler" | tee -a ${1}
    echo "" >> ${1}
    apt-get -y install gcc >> ${1} 2>&1 
    echo "" >> ${1}
    echo "" | tee -a ${1}

    # Install The Newest Versions Of All Newly Installed Packages On The System
    echo "Updating all newly installed packages" | tee -a ${1}
    echo "" >> ${1}
    apt-get update >> ${1} 2>&1 
    echo "Done" >> ${1}
    echo "" >> ${1}
    echo "" | tee -a ${1}

    # Write The End Timestamp To the Log File
    date >> ${1} 2>&1
    echo "Finished installing packages and libraries." >> ${1}
    echo "" >> ${1}

    # Return The Appropriate Value To The Calling Function
    ReturnCode=${TRUE}
    return ${ReturnCode}
}


#-------------------------------------------------------------------------------------------------#
#  NAME:        move_files()                                                                      #
#                                                                                                 #
#  PURPOSE:     This function moves files from one directory to another.                          #
#                                                                                                 #
#  PARAMETERS:  $1 - User name                                                                    #
#               $2 - File group                                                                   #
#               $3 - Log file name                                                                #
#                                                                                                 #
#  RETURNS:     TRUE  (1) - The files were moved to the appropriate directory                     #
#               FALSE (0) - The files were not moved                                              #
#-------------------------------------------------------------------------------------------------#
function move_files
{
    # Define All Local Variables Used
    local SourceDir=${SourceDir:=''}             # Source Directory
    local SDirExists=${SDirExists:=0}            # Source Directory Exists Flag
    local TargetDir=${TargetDir:=''}             # Target Directory
    local TDirExists=${TDirExists:=0}            # Target Directory Exists Flag
    local ReturnCode=${ReturnCode:=0}            # Function Return Code

    # Initialize The Appropriate Memory Variables
    SDirExists=${FALSE}
    SDirExists=${FALSE}
    ReturnCode=${FALSE}

    # Set The "Source" And "Target" Directories, Based On The File Group Specified
    if echo "${2}" | grep -q "Arduino"
    then
        SourceDir="/home/${1}/Downloads/Arduino_Sketches"
        TargetDir="/home/${1}/Arduino"
    elif echo "${2}" | grep -q "DHT"
    then
        SourceDir="/home/${1}/Downloads/DHT_Files"
        TargetDir="/home/${1}/Arduino/libraries"
    elif echo "${2}" | grep -q "Demo"
    then
        SourceDir="/home/${1}/Downloads/Db2_Demo_Programs"
        TargetDir="/home/${1}/Db2_Demo_Programs"
    else
        date >> ${3} 2>&1
        echo -n "ERROR: Unknown file group; " | tee -a ${3}
        echo "the file group \"${2}\" is not recognized/supported." | tee -a ${3}
        echo "" | tee -a ${3}
        return ${ReturnCode}
    fi

    # If The Appropriate "Source" Directory Does Not Exist, Display An Error Message And
    # Return To The Calling Function
    if [ -d ${SourceDir} ] 
    then
        SDirExists=${TRUE}
    else
        date >> ${3} 2>&1
        echo "ERROR: The directory \"${SourceDir}\" does not exist." | tee -a ${3}
        echo "" | tee -a ${3}
        return ${ReturnCode}
    fi

    # If The Appropriate "Target" Directory Does Not Exist, ...
    if [ -d ${TargetDir} ] 
    then
        TDirExists=${TRUE}
    else
        # If The Target Directory Is The "Demo_Programs" Directory, Try To Create It -
        # If It Can't Be Created, Display An Error Message And Return To The Calling Function
        if echo "${2}" | grep -q "Demo"
        then
            ReturnCode=$(mkdir -m 777 ${TargetDir} > /dev/null 2>&1; echo $?)
            if [ ${ReturnCode} -gt 0 ]
            then
                date >> ${3} 2>&1
                echo "ERROR: The directory \"${TargetDir}\" cannot be created." | tee -a ${3}
                echo "" | tee -a ${3}
                ReturnCode=${FALSE}
                return ${ReturnCode}
            fi 

        # If The Target Directory Is Something Else, Display An Error Message And
        # Return To The Calling Function
        else
            date >> ${3} 2>&1
            echo "ERROR: The directory \"${TargetDir}\" does not exist." | tee -a ${3}
            echo "" | tee -a ${3}
            return ${ReturnCode}
        fi
    fi

    # Copy The Files In The "Source" Directory To The "Target" Directory
    SourceDir="${SourceDir}/*"
    ReturnCode=$(cp -f -R ${SourceDir} ${TargetDir} > /dev/null 2>&1; echo $?)
    if [ ${ReturnCode} -gt 0 ]
    then
        date >> ${3} 2>&1
        echo "ERROR: Unable to copy files from \"${SourceDir}\" to \"${TargetDir}\"." | tee -a ${3}
        echo "" | tee -a ${3}
        ReturnCode=${FALSE}
        return ${ReturnCode}
    fi 

    # Set The Permissions Of The Files In The "Target" Directory So Everyone Can Access Them
    ReturnCode=$(chmod 777 -R ${TargetDir} > /dev/null 2>&1; echo $?)
    if [ ${ReturnCode} -gt 0 ]
    then
        date >> ${3} 2>&1
        echo "ERROR: Unable to remove files from \"${SourceDir}\"." | tee -a ${3}
        echo "" | tee -a ${3}
        ReturnCode=${FALSE}
        return ${ReturnCode}
    fi 

    # Delete The Files In The "Source" Directory (And The Source Directory Itself)
    SourceDir=$(echo "${SourceDir::-2}")
    ReturnCode=$(rm -R ${SourceDir} > /dev/null 2>&1; echo $?)
    if [ ${ReturnCode} -gt 0 ]
    then
        date >> ${3} 2>&1
        echo "ERROR: Unable to remove files from \"${SourceDir}\"." | tee -a ${3}
        echo "" | tee -a ${3}
        ReturnCode=${FALSE}
        return ${ReturnCode}
    fi 

    # Return The Appropriate Value To The Calling Function
    ReturnCode=${TRUE}
    return ${ReturnCode}
}


#=================================================================================================#
#  NAME:        main()                                                                            #
#                                                                                                 #
#  PURPOSE:     This is the main body of the script.                                              #
#                                                                                                 #
#  PARAMETERS:  $1 - Script key word                                                              #
#               $2 - Option                                                                       #
#                                                                                                 #
#  RETURNS:     0 - The script executed successfully                                              #
#               1 - The script did NOT execute successfully                                       #
#=================================================================================================#

# Define All Variables Used
TRUE=${TRUE:=1}                                  # Boolean TRUE
FALSE=${FALSE:=0}                                # Boolean FALSE

CurrentDir=${CurrentDir:=''}                     # Current Working Directory
LogFile=${LogFile:=''}                           # Log File Name
TimeStamp=${TimeStamp:=''}                       # Current Date And Time Value
UserName=${UserName:=''}                         # User Name
FileGroup=${FileGroup:=''}                       # File Group Identifier

# Initialize The Appropriate Memory Variables
CurrentDir=$(pwd)
LogFile="${CurrentDir}/maker_env_setup.log"
TimeStamp=$(date '+%m-%d-%Y:%H-%M-%S')

# Clear The Screen
clear

# Create A Log File In The Current Directory And Write Header Information To It
init_log_file ${LogFile}

# Display A "Setting Up" Message
echo "Setting up the Db2 maker environment software needed. Please wait ..."
date >> ${LogFile} 2>&1
echo "Set up script \"maker_env_setup.sh\" started." >> ${LogFile} 2>&1
echo "" | tee -a ${LogFile}

# If A Parameter Value Was Not Passed To This Shell Script When It Was Invoked, Display An 
# Error Message And Exit
if [ ${#1} -le 0 ]
then
    date >> ${LogFile} 2>&1
    echo -n "ERROR: This script must be called with a valid user name " | tee -a ${LogFile}
    echo "specified." | tee -a ${LogFile}
    echo "" | tee -a ${LogFile}
    exit 1
fi

# If A Parameter Value Was Provided, See If It Is A Valid User Name (If It's Not, Exit)
check_input_parameter ${1} ${LogFile}
ReturnCode=$?
if [ ${ReturnCode} == ${FALSE} ]
then
    exit 1
fi

# Install The Ubuntu Linux Libraries And Python Packages Needed
install_packages_and_libraries ${LogFile}

# Move The Arduino Sketch Files That Were Downloaded To the Appropriate Directory
FileGroup="Arduino"
move_files ${1} ${FileGroup} ${LogFile}
ReturnCode=$?
if [ ${ReturnCode} == ${FALSE} ]
then
    exit 1
fi

# Move The DHT22 Sensor Library Files That Were Downloaded To the Appropriate Directory
FileGroup="DHT"
move_files ${1} ${FileGroup} ${LogFile}
ReturnCode=$?
if [ ${ReturnCode} == ${FALSE} ]
then
    exit 1
fi

# Move The Demo Program Files That Were Downloaded To the Appropriate User Directory
FileGroup="Demo"
move_files ${1} ${FileGroup} ${LogFile}
ReturnCode=$?
if [ ${ReturnCode} == ${FALSE} ]
then
    exit 1
fi

# Write The End Timestamp To the Log File
date >> ${LogFile} 2>&1
echo "Finished moving files and cleaning up." >> ${LogFile}
echo "" >> ${LogFile}

# Display A "Finished" Message And Write A "Finished" Message To The Log File
echo ""
echo "Finished! Refer to the file \"${LogFile}\" for more information."
echo ""  | tee -a ${LogFile}

# Exit And Return Control To The Calling Script
exit 0

