#!/bin/bash
#-------------------------------------------------------------------------------------------------#
#  NAME:     maker_env_setup.sh                                                                   #
#                                                                                                 #
#  PURPOSE:  This program is designed to install the Ubuntu Linux libraries, Python packages,     #
#            and Arduino sketches that are needed to set up the UDOO X86 Db2-based maker project. #
#                                                                                                 #
#  USAGE:    Log in as the root user and issue the following command from a Linux terminal        #
#            window:                                                                              #
#                                                                                                 #
#                 ./maker_env_setup.sh                                                            #
#                                                                                                 #
#-------------------------------------------------------------------------------------------------#
#                      DISCLAIMER OF WARRANTIES AND LIMITATION OF LIABILITY                       #
#                                                                                                 #
#  (C) COPYRIGHT International Business Machines Corp. 2017, 2018 All Rights Reserved             #
#  Licensed Materials - Property of IBM                                                           #
#                                                                                                 #
#  US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP   #
#  Schedule Contract with IBM Corp.                                                               #
#                                                                                                 #
#  The following source code ("Sample") is owned by International Business Machines Corporation   #
#  or one of its subsidiaries ("IBM") and is copyrighted and licensed, not sold. You may use,     #
#  copy, modify, and distribute the Sample in any form without payment to IBM, for the purpose of #
#  assisting you in the creation of a simple database that is designed to store humidity and      #
#  temperature data.                                                                              #
#                                                                                                 #
#  The Sample code is provided to you on an "AS IS" basis, without warranty of any kind. IBM      #
#  HEREBY EXPRESSLY DISCLAIMS ALL WARRANTIES, EITHER EXPRESS OR IMPLIED, INCLUDING, BUT NOT       #
#  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.    #
#  Some jurisdictions do not allow for the exclusion or limitation of implied warranties, so the  #
#  above limitations or exclusions may not apply to you. IBM shall not be liable for any damages  #
#  you suffer as a result of using, copying, modifying or distributing the Sample, even if IBM    #
#  has been advised of the possibility of such damages.                                           #
#-------------------------------------------------------------------------------------------------#
#  HISTORY: 01JAN2018 - Initial Coding                                   roger.sanders@us.ibm.com #
#-------------------------------------------------------------------------------------------------#

# Define All Global Variables Used
CurrentDir=${CurrentDir:=''}                     # Current Directory
TimeStamp=${TimeStamp:=''}                       # Current Date And Time Value
LogFile=${LogFile:=''}                           # Log File Name

# Clear The Screen
clear

# Get The Current System Date And Time
TimeStamp=$(date '+%m-%d-%Y:%H-%M-%S')

# Create A New Log File In The Current Directory And Write Header Information To It
CurrentDir=$(pwd)
LogFile="${CurrentDir}/maker_env_setup.log"

echo "#------------------------------------------------------------------#"  > ${LogFile} 2>&1
echo "#  NAME:    maker_env_setup.log                                    #" >> ${LogFile} 2>&1
echo "#  CREATED: ${TimeStamp}                                    #" >> ${LogFile} 2>&1
echo "#------------------------------------------------------------------#" >> ${LogFile} 2>&1
echo "" >> ${LogFile} 2>&1

# Upgrade The Entire System
echo "" | tee -a ${LogFile}
echo "Removing packages that are no longer required." | tee -a ${LogFile}
echo "" >> ${LogFile}
apt -y autoremove >> ${LogFile} 2>&1 
echo "" >> ${LogFile}

# Upgrade The Entire System
echo "" | tee -a ${LogFile}
echo "Installing newer versions of all packages installed (this may take a few minutes)." | tee -a ${LogFile}
echo "" >> ${LogFile}
apt-get -y upgrade >> ${LogFile} 2>&1 
echo "" >> ${LogFile}

# Install The LIBAIO1 Linux Library
echo "" | tee -a ${LogFile}
echo "Installing the libaio1 package" | tee -a ${LogFile}
echo "" >> ${LogFile}
apt-get -y install libaio1 >> ${LogFile} 2>&1 
echo "" >> ${LogFile}
echo "" | tee -a ${LogFile}

# Install The BINUTILS Linux Library
echo "Installing the binutils package" | tee -a ${LogFile}
echo "" | tee -a ${LogFile}
apt-get -y install binutils >> ${LogFile} 2>&1  
echo "" >> ${LogFile}
echo "" >> ${LogFile}

# Install The ZLIB1G Linux Library
echo "Installing the zlib1g-dev package" | tee -a ${LogFile}
echo "" >> ${LogFile}
apt-get -y install zlib1g-dev >> ${LogFile} 2>&1 
echo "" >> ${LogFile}
echo "" | tee -a ${LogFile}

# Install The LIBPAM0G:I386 Linux Library
echo "Installing the libpam0g:i386 package" | tee -a ${LogFile}
echo "" >> ${LogFile}
apt-get -y install libpam0g:i386 >> ${LogFile} 2>&1 
echo "" >> ${LogFile}
echo "" | tee -a ${LogFile}

# Install The LIBSTDC++:I386 Linux Library
echo "Installing the libstdc++6:i386 package" | tee -a ${LogFile}
echo "" >> ${LogFile}
apt-get -y install libstdc++6:i386 >> ${LogFile} 2>&1 
echo "" >> ${LogFile}
echo "" | tee -a ${LogFile}

# Install The OPENSSH-SERVER Linux Library
echo "Installing the openssh-server package" | tee -a ${LogFile}
echo "" >> ${LogFile}
apt-get -y install openssh-server >> ${LogFile} 2>&1 
echo "" >> ${LogFile}
echo "" | tee -a ${LogFile}

# Install The ARDUINO-MK Linux Library
echo "Installing the arduino-mk package" | tee -a ${LogFile}
echo "" >> ${LogFile}
apt-get -y install arduino-mk >> ${LogFile} 2>&1 
echo "" >> ${LogFile}
echo "" | tee -a ${LogFile}

# Install The SETUPTOOLS Python 3.5 Package
echo "" >> ${LogFile}
echo "Installing the python3-setuptools package" | tee -a ${LogFile}
echo "" >> ${LogFile}
apt-get -y install python3-setuptools >> ${LogFile} 2>&1 
echo "" >> ${LogFile}

# Install The PIP Python 3.5 Package
echo "" | tee -a ${LogFile}
echo "Installing the python3-pip package" | tee -a ${LogFile}
echo "" >> ${LogFile}
apt-get -y install python3-pip >> ${LogFile} 2>&1 
echo "" >> ${LogFile}

# Upgrade The PIP Python 3.5 Package
echo "" | tee -a ${LogFile}
echo "Upgrading the Python pip application" | tee -a ${LogFile}
echo "" >> ${LogFile}
pip3 install -U pip >> ${LogFile} 2>&1 
echo "" >> ${LogFile}
echo "" | tee -a ${LogFile}

# Install The DEV Python 3.5 Package
echo "Installing the python3-dev package" | tee -a ${LogFile}
echo "" | tee -a ${LogFile}
apt-get -y install python3-dev >> ${LogFile} 2>&1  
echo "" >> ${LogFile}
echo "" >> ${LogFile}

# Install The LXML Python 3.5 Package
echo "Installing the python3-lxml package" | tee -a ${LogFile}
echo "" >> ${LogFile}
apt-get -y install python3-lxml >> ${LogFile} 2>&1 
echo "" >> ${LogFile}
echo "" | tee -a ${LogFile}

# Install The GCC Compiler
echo "Installing the gcc compiler" | tee -a ${LogFile}
echo "" >> ${LogFile}
apt-get -y install gcc >> ${LogFile} 2>&1 
echo "" >> ${LogFile}
echo "" | tee -a ${LogFile}

# Install The Newest Versions Of All Linux Packages On The System
echo "Updating all installed packages" | tee -a ${LogFile}
echo "" | tee -a ${LogFile}
apt-get update >> ${LogFile} 2>&1 
echo "Done" >> ${LogFile}
echo "" >> ${LogFile}
echo "" | tee -a ${LogFile}

# Change Permissions On The Log File And Indicate The Work Is Complete
chmod 777 ${LogFile}
echo "Finished! Refer to the file \"${LogFile}\" for more information."
