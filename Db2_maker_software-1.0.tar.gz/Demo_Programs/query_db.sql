-----------------------------------------------------------------------------------------------------
--  NAME:      query_db.sql                                                                        --
--                                                                                                 --
--  PURPOSE:   This Db2 Command Line Processor (CLP) script is designed to query a Db2 database    --
--             table that contains humidity and temperature data.                                  --
--                                                                                                 --
--  USAGE:     Log in as a Db2 database instance user (for example, db2inst1) and issue the        --
--             following command from a terminal window (Linux):                                   --
--                                                                                                 --
--                 db2 -tf query_db.sql                                                            --
--                                                                                                 --
-----------------------------------------------------------------------------------------------------
--                      DISCLAIMER OF WARRANTIES AND LIMITATION OF LIABILITY                       --
--                                                                                                 --
--  (C) COPYRIGHT International Business Machines Corp. 2017 All Rights Reserved                   --
--  Licensed Materials - Property of IBM                                                           --
--                                                                                                 --
--  US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP   --
--  Schedule Contract with IBM Corp.                                                               --
--                                                                                                 --
--  The following source code ("Sample") is owned by International Business Machines Corporation   --
--  or one of its subsidiaries ("IBM") and is copyrighted and licensed, not sold. You may use,     --
--  copy, modify, and distribute the Sample in any form without payment to IBM, for the purpose of --
--  assisting you in the creation of a simple database that is designed to store humidity and      --
--  temperature data.                                                                              --
--                                                                                                 --
--  The Sample code is provided to you on an "AS IS" basis, without warranty of any kind. IBM      --
--  HEREBY EXPRESSLY DISCLAIMS ALL WARRANTIES, EITHER EXPRESS OR IMPLIED, INCLUDING, BUT NOT       --
--  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.    --
--  Some jurisdictions do not allow for the exclusion or limitation of implied warranties, so the  --
--  above limitations or exclusions may not apply to you. IBM shall not be liable for any damages  --
--  you suffer as a result of using, copying, modifying or distributing the Sample, even if IBM    --
--  has been advised of the possibility of such damages.                                           --
-----------------------------------------------------------------------------------------------------
--  HISTORY: 26SEP2017 - Initial Coding                                   roger.sanders@us.ibm.com --
-----------------------------------------------------------------------------------------------------

-- Clear The Screen And Start The DB2 Database Manager (If It Is Not Already Running)
!clear;
!db2start;

-- Connect To The MY_DATA Database
CONNECT TO my_data;

-- Query The UDOO.DHT22_DATA Table To Verify That It Was Populated
SELECT record_num, 
       time_collected, 
       DECIMAL(pct_humidity, 5, 2) AS HUMIDITY,
       DECIMAL(temp_c, 5, 2) AS TEMP_CELSIUS,
       DECIMAL(heat_index_c, 5, 2) AS HEAT_INDEX_C,
       DECIMAL(temp_f, 5, 2) AS TEMP_FAHRENHEIT,
       DECIMAL(heat_index_f, 5, 2) AS HEAT_INDEX_F
       FROM udoo.dht22_data
           ORDER BY time_collected DESC
           FETCH FIRST 10 ROWS ONLY;

-- Terminate The Database Connection
CONNECT RESET;
